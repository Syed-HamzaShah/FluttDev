import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/foundation.dart';
import '../models/post_model.dart';
import 'package:flutter/material.dart';

// Interface for notifications
abstract class NotificationService {
  Future<void> requestPermission();
  Future<void> subscribeAll();
  Future<void> sendNewPostNotification(PostModel post);
  Future<void> initialize();
  Future<void> sendTestNotification();
}

class PlaceholderNotificationService implements NotificationService {
  @override
  Future<void> requestPermission() async {
    debugPrint(
      '⚠️ PlaceholderNotificationService: requestPermission called (no-op)',
    );
  }

  @override
  Future<void> subscribeAll() async {
    debugPrint(
      '⚠️ PlaceholderNotificationService: subscribeAll called (no-op)',
    );
  }

  @override
  Future<void> sendNewPostNotification(PostModel post) async {
    debugPrint(
      '⚠️ PlaceholderNotificationService: sendNewPostNotification called (no-op) for post ${post.id}',
    );
  }

  @override
  Future<void> initialize() async {
    debugPrint('⚠️ PlaceholderNotificationService: initialize called (no-op)');
  }

  @override
  Future<void> sendTestNotification() async {
    debugPrint(
      '⚠️ PlaceholderNotificationService: sendTestNotification called (no-op)',
    );
  }
}

class FCMNotificationService implements NotificationService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  bool _awesomeNotificationsInitialized = false;

  @override
  Future<void> requestPermission() async {
    try {
      debugPrint('🔔 Requesting Firebase messaging permissions...');
      // Request Firebase messaging permission
      final fcmSettings = await _messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      debugPrint(
        '🔔 FCM permission status: ${fcmSettings.authorizationStatus}',
      );

      debugPrint('🔔 Requesting Awesome Notifications permissions...');
      // Request awesome notifications permission
      final awesomePermission =
          await AwesomeNotifications().requestPermissionToSendNotifications();
      debugPrint('🔔 Awesome Notifications permission: $awesomePermission');
    } catch (e) {
      debugPrint('❌ Error requesting notification permissions: $e');
    }
  }

  @override
  Future<void> subscribeAll() async {
    await _messaging.subscribeToTopic('all');
  }

  @override
  Future<void> sendNewPostNotification(PostModel post) async {
    try {
      debugPrint(
        '🔔 FCMNotificationService: Sending notification for post ${post.id}',
      );
      debugPrint(
        '📱 Post details: ${post.createdByName} - ${post.description}',
      );
      // Check if Awesome Notifications is initialized
      if (!_awesomeNotificationsInitialized) {
        debugPrint(
          '❌ Awesome Notifications not initialized, initializing now...',
        );
        await initialize();
      }

      // Send local notification using awesome_notifications
      debugPrint('📱 Creating local notification...');
      final notificationId = DateTime.now().millisecondsSinceEpoch.remainder(
        100000,
      );

      // Handle null/empty values safely
      final title = 'New Post by ${post.createdByName ?? 'Unknown User'}';
      final body =
          post.description?.isNotEmpty == true
              ? (post.description!.length > 100
                  ? '${post.description!.substring(0, 100)}...'
                  : post.description!)
              : 'New post shared!';

      await AwesomeNotifications().createNotification(
        content: NotificationContent(
          id: notificationId,
          channelKey: 'new_post_channel',
          title: title,
          body: body,
          notificationLayout:
              post.mediaUrl?.isNotEmpty == true
                  ? NotificationLayout.BigPicture
                  : NotificationLayout.BigText,
          bigPicture: post.mediaUrl?.isNotEmpty == true ? post.mediaUrl : null,
          payload: {
            'post_id': post.id ?? 'unknown',
            'user_id': post.createdBy ?? 'unknown',
          },
        ),
      );
      debugPrint('✅ Local notification created with ID: $notificationId');

      // Also send FCM notification to all subscribed users
      await _sendFCMNotification(post);
    } catch (e) {
      debugPrint('❌ Error sending notification: $e');
      debugPrint('❌ Error stack trace: ${StackTrace.current}');
    }
  }

  Future<void> _sendFCMNotification(PostModel post) async {
    try {
      // This would typically be handled by a backend service
      // For now, we'll just log that we would send an FCM notification
      debugPrint('Would send FCM notification for post: ${post.id}');

      // In a real implementation, you would:
      // 1. Send a request to your backend
      // 2. Backend would send FCM notification to all users subscribed to 'all' topic
      // 3. Or use Supabase Edge Functions to handle this
    } catch (e) {
      debugPrint('Error sending FCM notification: $e');
    }
  }

  @override
  Future<void> initialize() async {
    try {
      debugPrint('🔔 Initializing Awesome Notifications...');

      // Initialize awesome notifications
      await AwesomeNotifications().initialize(
        null, // Use default app icon
        [
          NotificationChannel(
            channelKey: 'new_post_channel',
            channelName: 'New Posts',
            channelDescription: 'Notifications for new posts',
            defaultColor: const Color(0xFF9D50DD),
            ledColor: Colors.white,
            importance: NotificationImportance.High,
            channelShowBadge: true,
            playSound: true,
            enableVibration: true,
            enableLights: true,
            ledOnMs: 1000,
            ledOffMs: 500,
          ),
        ],
        debug: kDebugMode,
      );

      _awesomeNotificationsInitialized = true;
      debugPrint('✅ Awesome Notifications initialized successfully');

      // Set up FCM background message handler
      debugPrint('🔔 Setting up FCM background message handler...');
      FirebaseMessaging.onBackgroundMessage(
        _firebaseMessagingBackgroundHandler,
      );
      debugPrint('✅ FCM background message handler set up');
    } catch (e) {
      debugPrint('❌ Error initializing notification service: $e');
      debugPrint('❌ Error stack trace: ${StackTrace.current}');
    }
  }

  @override
  Future<void> sendTestNotification() async {
    try {
      debugPrint('🧪 Sending test notification...');
      // Check if Awesome Notifications is initialized
      if (!_awesomeNotificationsInitialized) {
        debugPrint(
          '❌ Awesome Notifications not initialized, initializing now...',
        );
        await initialize();
      }

      final notificationId = DateTime.now().millisecondsSinceEpoch.remainder(
        100000,
      );

      await AwesomeNotifications().createNotification(
        content: NotificationContent(
          id: notificationId,
          channelKey: 'new_post_channel',
          title: 'Test Notification',
          body: 'This is a test notification to verify the system is working!',
          notificationLayout: NotificationLayout.BigText,
        ),
      );

      debugPrint('✅ Test notification sent with ID: $notificationId');
    } catch (e) {
      debugPrint('❌ Error sending test notification: $e');
    }
  }
}

// Top-level function for FCM background message handling
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint('Handling a background message: ${message.messageId}');
}
