import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/post_model.dart';
import '../models/user_model.dart';
import 'notification_service.dart';

class SupabasePostsService extends ChangeNotifier {
  final SupabaseClient _client = Supabase.instance.client;
  final NotificationService _notificationService;

  List<PostModel> _posts = [];
  bool _isLoading = false;
  RealtimeChannel? _postsChannel;

  SupabasePostsService({NotificationService? notificationService})
    : _notificationService =
          notificationService ?? PlaceholderNotificationService() {
    debugPrint(
      '🏗️ SupabasePostsService initialized with notification service: ${_notificationService.runtimeType}',
    );
  }

  List<PostModel> get posts => List.unmodifiable(_posts);
  bool get isLoading => _isLoading;

  /// Initialize real-time streaming of posts
  Future<void> initializePostsStream() async {
    _isLoading = true;
    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      notifyListeners();
    });

    try {
      // First, load existing posts
      final response = await _client
          .from('posts')
          .select()
          .order('createdat', ascending: false);

      debugPrint('Raw response from Supabase: $response');
      final rows = response as List<dynamic>;
      debugPrint('Number of posts found: ${rows.length}');

      _posts =
          rows.map((row) {
            debugPrint('Processing row: $row');
            return PostModel.fromMap(row as Map<String, dynamic>);
          }).toList();

      // Set up real-time subscription
      debugPrint('📡 Setting up real-time subscription for posts table...');
      _postsChannel = _client
          .channel('posts_channel')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'posts',
            callback: (payload) {
              debugPrint('🔔 CALLBACK TRIGGERED! Real-time event received');
              _handleRealtimeChange(payload);
            },
          )
          .subscribe((status, error) {
            if (error != null) {
              debugPrint('❌ Real-time subscription error: $error');
              debugPrint('❌ This might be due to:');
              debugPrint(
                '   1. Supabase real-time not enabled for your project',
              );
              debugPrint('   2. RLS policies blocking real-time access');
              debugPrint('   3. Network connectivity issues');
            } else {
              debugPrint('✅ Real-time subscription status: $status');
              if (status == RealtimeSubscribeStatus.subscribed) {
                debugPrint('🎉 Real-time subscription is active and ready!');
                debugPrint('🔍 Waiting for database changes...');
              }
            }
          });

      debugPrint('✅ Real-time subscription established for posts table');

      // Add a listener to check if the channel is actually receiving events
      _postsChannel?.onBroadcast(
        event: '*',
        callback: (payload) {
          debugPrint('📡 Channel broadcast received: $payload');
        },
      );
    } catch (e) {
      debugPrint('Supabase initializePostsStream error: $e');
      debugPrint('Error type: ${e.runtimeType}');
      if (e.toString().contains('column')) {
        debugPrint(
          'This looks like a column name issue. Check your database schema.',
        );
      }
    } finally {
      _isLoading = false;
      // Use post-frame callback to avoid setState during build
      WidgetsBinding.instance.addPostFrameCallback((_) {
        notifyListeners();
      });
    }
  }

  /// Handle real-time changes to posts
  void _handleRealtimeChange(PostgresChangePayload payload) {
    try {
      debugPrint('🔄 Real-time change detected: ${payload.eventType}');
      debugPrint('📊 Payload: $payload');

      switch (payload.eventType) {
        case PostgresChangeEvent.insert:
          final newPost = PostModel.fromMap(payload.newRecord);
          _posts.insert(0, newPost);

          debugPrint(
            '📝 New post inserted: ${newPost.id} by ${newPost.createdByName}',
          );
          debugPrint('🔔 Sending notification...');

          // Send notification for new post
          _notificationService.sendNewPostNotification(newPost);
          break;
        case PostgresChangeEvent.update:
          final updatedPost = PostModel.fromMap(payload.newRecord);
          final index = _posts.indexWhere((p) => p.id == updatedPost.id);
          if (index != -1) {
            _posts[index] = updatedPost;
          }
          break;
        case PostgresChangeEvent.delete:
          final deletedId = payload.oldRecord['id'] as String;
          _posts.removeWhere((p) => p.id == deletedId);
          break;
        default:
          // Handle any other event types if needed
          debugPrint('Unhandled PostgresChangeEvent: ${payload.eventType}');
          break;
      }
      notifyListeners();
    } catch (e) {
      debugPrint('Error handling realtime change: $e');
    }
  }

  /// Load all posts, newest first (legacy method for refresh)
  Future<void> loadPosts() async {
    await initializePostsStream();
  }

  /// Reset the service (clear data and unsubscribe)
  void reset() {
    _postsChannel?.unsubscribe();
    _postsChannel = null;
    _posts.clear();
    _isLoading = false;
    notifyListeners();
  }

  /// Dispose resources
  @override
  void dispose() {
    _postsChannel?.unsubscribe();
    super.dispose();
  }

  /// Create a new post
  Future<bool> createPost({
    required String description,
    String? mediaUrl,
    required UserModel user,
  }) async {
    try {
      final data = {
        'description': description,
        'mediaUrl': mediaUrl,
        'createdBy': user.id, // user.id must be a UUID string
        'createdByName': user.name,
        'createdByAvatar': user.profileImageUrl,
        'createdAt': DateTime.now().toIso8601String(),
      };

      final inserted =
          await _client.from('posts').insert(data).select().single();

      final saved = PostModel.fromMap(inserted);
      _posts.insert(0, saved);

      // Send notification for the new post
      _notificationService.sendNewPostNotification(saved);

      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Supabase createPost error: $e');
      return false;
    }
  }

  /// Test notification system manually
  Future<void> testNotificationSystem() async {
    debugPrint('🧪 Testing notification system manually...');

    // Create a test post
    final testPost = PostModel(
      id: 'test-${DateTime.now().millisecondsSinceEpoch}',
      description:
          'This is a test notification to verify the system is working!',
      createdBy: 'test-user',
      createdByName: 'Test User',
      createdAt: DateTime.now(),
    );

    // Send notification
    await _notificationService.sendNewPostNotification(testPost);
    debugPrint('✅ Test notification sent');
  }

  /// Test real-time subscription by creating a test post
  Future<void> testRealtimeSubscription() async {
    debugPrint('🧪 Testing real-time subscription...');

    try {
      final testData = {
        'description':
            'Test post for real-time subscription - ${DateTime.now()}',
        'createdBy': '550e8400-e29b-41d4-a716-446655440000',
        'createdByName': 'Test User',
        'createdByAvatar':
            'https://ui-avatars.com/api/?name=Test+User&size=200',
        'createdAt': DateTime.now().toIso8601String(),
      };

      debugPrint('📝 Inserting test post to trigger real-time event...');
      final inserted =
          await _client.from('posts').insert(testData).select().single();
      debugPrint('✅ Test post inserted: ${inserted['id']}');
      debugPrint('🔍 Watch for real-time callback in the next few seconds...');
    } catch (e) {
      debugPrint('❌ Error testing real-time subscription: $e');
    }
  }

  /// Check Supabase real-time configuration
  Future<void> checkRealtimeConfig() async {
    debugPrint('🔍 Checking Supabase real-time configuration...');

    try {
      // Check if we can access the real-time API
      final response = await _client.realtime.getChannels();
      debugPrint('📡 Active channels: ${response.length}');

      // Check if the posts table exists and is accessible
      final tableCheck = await _client.from('posts').select('count').limit(1);
      debugPrint('📊 Posts table accessible: ${tableCheck.isNotEmpty}');

      // Check channel status
      if (_postsChannel != null) {
        debugPrint('📡 Posts channel exists: posts_channel');
        debugPrint('📡 Channel is active');
      } else {
        debugPrint('❌ Posts channel is null');
      }
    } catch (e) {
      debugPrint('❌ Error checking real-time config: $e');
    }
  }
}
